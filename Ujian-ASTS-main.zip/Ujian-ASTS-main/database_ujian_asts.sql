CREATE DATABASE IF NOT EXISTS ujian_asts
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ujian_asts;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    nisn VARCHAR(30) NOT NULL,
    ttl VARCHAR(150) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NULL,
    address TEXT NOT NULL,
    password_hash VARCHAR(255) NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

  INSERT IGNORE INTO users (name, nisn, ttl, gender, email, phone, address, password_hash, role) VALUES
('Leanne Graham', '2026000001', 'Gwenborough, tanggal lahir tidak tersedia', 'male', 'Sincere@april.biz', NULL, 'Kulas Light, Apt. 556, Gwenborough, 92998-3874', NULL, 'user'),
('Ervin Howell', '2026000002', 'Wisokyburgh, tanggal lahir tidak tersedia', 'female', 'Shanna@melissa.tv', NULL, 'Victor Plains, Suite 879, Wisokyburgh, 90566-7771', NULL, 'user'),
('Clementine Bauch', '2026000003', 'McKenziehaven, tanggal lahir tidak tersedia', 'male', 'Nathan@yesenia.net', NULL, 'Douglas Extension, Suite 847, McKenziehaven, 59590-4157', NULL, 'user'),
('Patricia Lebsack', '2026000004', 'South Elvis, tanggal lahir tidak tersedia', 'female', 'Julianne.OConner@kory.org', NULL, 'Hoeger Mall, Apt. 692, South Elvis, 53919-4257', NULL, 'user'),
('Chelsey Dietrich', '2026000005', 'Roscoeview, tanggal lahir tidak tersedia', 'male', 'Lucio_Hettinger@annie.ca', NULL, 'Skiles Walks, Suite 351, Roscoeview, 33263-0494', NULL, 'user'),
('Mrs. Dennis Schulist', '2026000006', 'South Christy, tanggal lahir tidak tersedia', 'female', 'Karley.Dach@jasper.info', NULL, 'Norberto Crossing, Apt. 950, South Christy, 23505-1337', NULL, 'user'),
('Kurtis Weissnat', '2026000007', 'Howemouth, tanggal lahir tidak tersedia', 'male', 'Telly.Hoeger@billy.biz', NULL, 'Rex Trail, Suite 280, Howemouth, 58804-1099', NULL, 'user'),
('Nicholas Runolfsdottir V', '2026000008', 'Aliyaview', 'female', 'Sherwood@rosamond.me', NULL, 'Ellsworth Summit, Suite 729, Aliyaview', NULL, 'user'),
('Glenna Reichert', '2026000009', 'Bartholomebury, tanggal lahir tidak tersedia', 'male', 'Chaim_McDermott@dana.io', NULL, 'Dayna Park, Suite 449, Bartholomebury, 76495-3109', NULL, 'user'),
('Clementina DuBuque', '2026000010', 'South Alfred', 'female', 'Rey.Padberg@karina.biz', NULL, 'Kattie Turnpike, Suite 198, South Alfred, 31428-2261', NULL, 'user');
