<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax',
    ]);
    session_start();
}

function jsonResponse(string $status, string $message, ?array $data = null, int $httpCode = 200, ?array $meta = null): never
{
    http_response_code($httpCode);
    $response = ['status' => $status, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    if ($meta !== null) {
        $response['meta'] = $meta;
    }
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function requestData(): array
{
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}

function authenticatedUser(PDO $pdo): array
{
    $userId = $_SESSION['user_id'] ?? null;
    if (!is_int($userId) || $userId < 1) {
        jsonResponse('error', 'Silakan login terlebih dahulu.', null, 401);
    }

    $stmt = $pdo->prepare('SELECT id, name, nisn, ttl, gender, email, phone, address, role, is_active, created_at, last_login_at FROM users WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    if (!$user) {
        $_SESSION = [];
        session_destroy();
        jsonResponse('error', 'Akun tidak ditemukan. Silakan login kembali.', null, 401);
    }
    if (!(int) $user['is_active']) {
        $_SESSION = [];
        session_destroy();
        jsonResponse('error', 'Akun Anda sedang dinonaktifkan. Hubungi admin.', null, 403);
    }
    if (!in_array($user['role'], ['admin', 'user'], true)) {
        $_SESSION = [];
        session_destroy();
        jsonResponse('error', 'Role akun tidak dikenali. Hubungi admin.', null, 403);
    }

    return $user;
}

function requireAdmin(array $user): void
{
    if ($user['role'] !== 'admin') {
        jsonResponse('error', 'Akses khusus admin.', null, 403);
    }
}

function normalizePhone(string $phone): string
{
    $digits = preg_replace('/\D+/', '', $phone) ?? '';
    if (str_starts_with($digits, '0')) {
        $digits = '62' . substr($digits, 1);
    } elseif (str_starts_with($digits, '8')) {
        $digits = '62' . $digits;
    }
    return $digits;
}

function notificationTime(): string
{
    return (new DateTimeImmutable('now', new DateTimeZone('Asia/Jakarta')))->format('d/m/Y H:i') . ' WIB';
}

function notificationMessage(string $title, array $lines, string $emoji = '🔔'): string
{
    $formattedLines = [];
    foreach ($lines as $line) {
        $parts = preg_split('/\r\n|\r|\n/', trim((string) $line)) ?: [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            $formattedLines[] = str_starts_with($part, '•') ? '  ' . $part : '• ' . $part;
        }
    }

    return '*' . $emoji . ' ' . $title . "*\n"
        . "━━━━━━━━━━━━━━\n"
        . implode("\n", $formattedLines)
        . "\n\n📬 _Portal ASTS · Notifikasi otomatis_";
}

function sendWhatsApp(PDO $pdo, ?string $phone, string $message): bool
{
    $target = normalizePhone((string) $phone);
    if ($target === '') {
        return false;
    }

    $configPath = __DIR__ . '/fonnte.php';
    if (!is_file($configPath)) {
        error_log('Fonnte config file is missing.');
        return false;
    }

    try {
        $config = require $configPath;
        $token = is_array($config) ? trim((string) ($config['token'] ?? '')) : '';
        if ($token === '' || !function_exists('curl_init')) {
            error_log('Fonnte token is missing or PHP cURL is unavailable.');
            return false;
        }

        $curl = curl_init('https://api.fonnte.com/send');
        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => ['target' => $target, 'message' => $message],
            CURLOPT_HTTPHEADER => ['Authorization: ' . $token],
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($curl);
        $statusCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        if ($response === false || $statusCode < 200 || $statusCode >= 300) {
            error_log('Fonnte request failed: ' . ($error !== '' ? $error : 'HTTP ' . $statusCode));
            return false;
        }

        $result = json_decode($response, true);
        if (!is_array($result) || empty($result['status'])) {
            error_log('Fonnte rejected a notification request.');
            return false;
        }
        return true;
    } catch (Throwable $error) {
        error_log('Fonnte notification error: ' . $error->getMessage());
        return false;
    }
}

function notifyAdmins(PDO $pdo, string $message): void
{
    $stmt = $pdo->query("SELECT phone FROM users WHERE role = 'admin' AND phone IS NOT NULL AND phone <> ''");
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $phone) {
        sendWhatsApp($pdo, (string) $phone, $message);
    }
}

function publicUser(array $user): array
{
    unset($user['password_hash']);
    return $user;
}