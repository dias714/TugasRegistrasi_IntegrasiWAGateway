<?php
return ['token' => '6GnEG3GJe6FjujSum2Hf'];