<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');
require __DIR__ . '/app_common.php';
require __DIR__ . '/koneksi.php';

try {
    $actor = authenticatedUser($pdo);
    $method = $_SERVER['REQUEST_METHOD'];
    $id = isset($_GET['id']) ? (int) $_GET['id'] : (int) $actor['id'];

    if ($method === 'GET') {
        if ($actor['role'] === 'admin' && !isset($_GET['id'])) {
            $stmt = $pdo->query('SELECT id, name, nisn, ttl, gender, email, phone, address, role, password_hash, is_active, created_at, last_login_at FROM users ORDER BY id ASC');
            $users = array_map(static function (array $user): array {
                $user['has_password'] = !empty($user['password_hash']);
                return publicUser($user);
            }, $stmt->fetchAll());
            $metricStmt = $pdo->query(
                'SELECT COUNT(*) AS total_users,
                        SUM(CASE WHEN last_login_at >= CURDATE() THEN 1 ELSE 0 END) AS daily_active_users,
                        SUM(CASE WHEN created_at >= CURDATE() THEN 1 ELSE 0 END) AS new_users_today
                 FROM users'
            );
            $metrics = $metricStmt->fetch();
            foreach ($metrics as $key => $value) {
                $metrics[$key] = (int) $value;
            }
            jsonResponse('success', 'Data semua user berhasil diambil.', $users, 200, ['metrics' => $metrics]);
        }
        if ($actor['role'] !== 'admin') {
            $id = (int) $actor['id'];
        }
        $stmt = $pdo->prepare('SELECT id, name, nisn, ttl, gender, email, phone, address, role FROM users WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $user = $stmt->fetch();
        if (!$user) {
            jsonResponse('error', 'Data user tidak ditemukan.', null, 404);
        }
        jsonResponse('success', 'Profil berhasil diambil.', [$user]);
    }

    if ($method === 'POST') {
        requireAdmin($actor);
        $input = requestData();
        $required = ['name', 'nisn', 'ttl', 'gender', 'email', 'phone', 'address', 'password'];
        foreach ($required as $field) {
            if (trim((string) ($input[$field] ?? '')) === '') {
                jsonResponse('error', "Field {$field} wajib diisi.", null, 422);
            }
        }
        if (!filter_var((string) $input['email'], FILTER_VALIDATE_EMAIL) || strlen((string) $input['password']) < 8) {
            jsonResponse('error', 'Email tidak valid atau password kurang dari 8 karakter.', null, 422);
        }
        if (!preg_match('/^\d{10}$/', trim((string) $input['nisn']))) {
            jsonResponse('error', 'NISN harus terdiri dari tepat 10 angka.', null, 422);
        }
        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email');
        $check->execute([':email' => trim((string) $input['email'])]);
        if ($check->fetch()) {
            jsonResponse('error', 'Email sudah terdaftar.', null, 409);
        }
        $phone = normalizePhone((string) $input['phone']);
        if (strlen($phone) < 10 || strlen($phone) > 15) {
            jsonResponse('error', 'Nomor HP harus berisi 10 sampai 15 angka.', null, 422);
        }
        $stmt = $pdo->prepare(
            "INSERT INTO users (name, nisn, ttl, gender, email, phone, address, password_hash, role)
             VALUES (:name, :nisn, :ttl, :gender, :email, :phone, :address, :password_hash, 'user')"
        );
        $stmt->execute([
            ':name' => trim((string) $input['name']),
            ':nisn' => trim((string) $input['nisn']),
            ':ttl' => trim((string) $input['ttl']),
            ':gender' => trim((string) $input['gender']),
            ':email' => trim((string) $input['email']),
            ':phone' => $phone,
            ':address' => trim((string) $input['address']),
            ':password_hash' => password_hash((string) $input['password'], PASSWORD_DEFAULT),
        ]);
        $newUserName = trim((string) $input['name']);
        $newUserEmail = trim((string) $input['email']);
        sendWhatsApp($pdo, $phone, notificationMessage('Akun Anda siap digunakan', [
            'Halo ' . $newUserName . ' 👋',
            'Admin telah membuat akun Portal ASTS untuk Anda.',
            'Email login: ' . $newUserEmail,
            'Gunakan password yang diberikan admin untuk masuk. Password tidak pernah dikirim melalui notifikasi ini.',
            'Jika Anda tidak mengenali pembuatan akun ini, hubungi admin.',
        ], '🎉'));
        notifyAdmins($pdo, notificationMessage('Pengguna ditambahkan admin', [
            'Nama: ' . $newUserName,
            'Email: ' . $newUserEmail,
            'Waktu: ' . notificationTime(),
            'Akun dapat ditinjau melalui Dashboard Admin.',
        ], '👤'));
        jsonResponse('success', 'Akun user berhasil dibuat.', ['id' => (int) $pdo->lastInsertId()], 201);
    }

    if ($method === 'PUT') {
        if ($actor['role'] !== 'admin') {
            $id = (int) $actor['id'];
        }
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $oldUser = $stmt->fetch();
        if (!$oldUser) {
            jsonResponse('error', 'Data user tidak ditemukan.', null, 404);
        }
        if ($actor['role'] !== 'admin' && $oldUser['role'] === 'admin') {
            jsonResponse('error', 'Akses ditolak.', null, 403);
        }

        $input = requestData();
        $fields = ['name', 'nisn', 'ttl', 'gender', 'email', 'phone', 'address'];
        $labels = ['name' => 'Nama', 'nisn' => 'NISN', 'ttl' => 'TTL', 'gender' => 'Gender', 'email' => 'Email', 'phone' => 'Nomor HP', 'address' => 'Alamat'];
        $values = [];
        foreach ($fields as $field) {
            $values[$field] = trim((string) ($input[$field] ?? $oldUser[$field] ?? ''));
            if ($values[$field] === '') {
                jsonResponse('error', "Field {$field} wajib diisi.", null, 422);
            }
        }
        if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{10}$/', $values['nisn'])) {
            jsonResponse('error', 'Email atau NISN tidak valid.', null, 422);
        }
        $values['phone'] = normalizePhone($values['phone']);
        if (strlen($values['phone']) < 10 || strlen($values['phone']) > 15) {
            jsonResponse('error', 'Nomor HP harus berisi 10 sampai 15 angka.', null, 422);
        }
        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id <> :id');
        $check->execute([':email' => $values['email'], ':id' => $id]);
        if ($check->fetch()) {
            jsonResponse('error', 'Email sudah digunakan akun lain.', null, 409);
        }

        $changed = [];
        $changeDetails = [];
        foreach ($fields as $field) {
            if ((string) ($oldUser[$field] ?? '') !== $values[$field]) {
                $changed[] = $labels[$field];
                $oldValue = preg_replace('/[\r\n]+/', ' ', trim((string) ($oldUser[$field] ?? ''))) ?? '';
                $newValue = preg_replace('/[\r\n]+/', ' ', $values[$field]) ?? $values[$field];
                if ($field === 'gender') {
                    $oldValue = $oldValue === 'male' ? 'Laki-laki' : ($oldValue === 'female' ? 'Perempuan' : $oldValue);
                    $newValue = $values[$field] === 'male' ? 'Laki-laki' : 'Perempuan';
                }
                $oldValue = $oldValue !== '' ? $oldValue : '(kosong)';
                $changeDetails[] = $labels[$field] . ': ' . $oldValue . ' → ' . $newValue;
            }
        }
        $password = (string) ($input['password'] ?? '');
        $passwordHash = null;
        if ($password !== '') {
            if (strlen($password) < 8) {
                jsonResponse('error', 'Password minimal 8 karakter.', null, 422);
            }
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $changed[] = 'Password';
            $changeDetails[] = 'Password: diganti (nilai dirahasiakan)';
        }
        if (!$changed) {
            jsonResponse('success', 'Tidak ada perubahan data.', publicUser($oldUser));
        }

        $sql = 'UPDATE users SET name = :name, nisn = :nisn, ttl = :ttl, gender = :gender, email = :email, phone = :phone, address = :address';
        $params = [
            ':name' => $values['name'], ':nisn' => $values['nisn'], ':ttl' => $values['ttl'],
            ':gender' => $values['gender'], ':email' => $values['email'], ':phone' => $values['phone'],
            ':address' => $values['address'], ':id' => $id,
        ];
        if ($passwordHash !== null) {
            $sql .= ', password_hash = :password_hash';
            $params[':password_hash'] = $passwordHash;
        }
        $sql .= ' WHERE id = :id';
        $update = $pdo->prepare($sql);
        $update->execute($params);
        $targetPhone = (string) ($oldUser['phone'] ?: $values['phone']);
        sendWhatsApp($pdo, $targetPhone, notificationMessage('Profil berhasil diperbarui', [
            'Halo ' . $oldUser['name'] . '.',
            "Rincian perubahan:\n• " . implode("\n• ", $changeDetails),
            'Waktu perubahan: ' . notificationTime(),
            'Jika Anda tidak meminta perubahan ini, segera hubungi admin.',
        ], '📝'));
        $fresh = $pdo->prepare('SELECT id, name, nisn, ttl, gender, email, phone, address, role FROM users WHERE id = :id');
        $fresh->execute([':id' => $id]);
        jsonResponse('success', 'Data Anda berhasil diubah: ' . implode(', ', $changed) . '.', $fresh->fetch());
    }

    if ($method === 'PATCH') {
        requireAdmin($actor);
        $input = requestData();
        if (!isset($input['is_active']) || !in_array($input['is_active'], [0, 1, '0', '1'], true)) {
            jsonResponse('error', 'Status akun tidak valid.', null, 422);
        }
        $newStatus = (int) $input['is_active'];
        if ($id === (int) $actor['id'] && $newStatus === 0) {
            jsonResponse('error', 'Admin tidak dapat menonaktifkan akunnya sendiri.', null, 403);
        }
        $stmt = $pdo->prepare('SELECT id, name, phone, is_active FROM users WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $target = $stmt->fetch();
        if (!$target) {
            jsonResponse('error', 'Akun tidak ditemukan.', null, 404);
        }
        if ((int) $target['is_active'] !== $newStatus) {
            $update = $pdo->prepare('UPDATE users SET is_active = :is_active WHERE id = :id');
            $update->execute([':is_active' => $newStatus, ':id' => $id]);
            $statusLabel = $newStatus === 1 ? 'Aktif' : 'Nonaktif';
            $statusLines = [
                'Halo ' . $target['name'] . '.',
                'Status akun Anda sekarang: ' . $statusLabel . '.',
                'Waktu pembaruan: ' . notificationTime(),
            ];
            $statusLines[] = $newStatus === 1
                ? 'Anda dapat login kembali ke Portal ASTS.'
                : 'Akses login sementara dinonaktifkan. Hubungi admin jika memerlukan bantuan.';
            sendWhatsApp($pdo, $target['phone'], notificationMessage('Status akun diperbarui', $statusLines, '⚙️'));
        }
        jsonResponse('success', $newStatus === 1 ? 'Akun diaktifkan.' : 'Akun dinonaktifkan.', ['id' => $id, 'is_active' => $newStatus]);
    }

    if ($method === 'DELETE') {
        if ($actor['role'] !== 'admin') {
            $id = (int) $actor['id'];
        }
        if ($actor['role'] === 'admin' && $id === (int) $actor['id']) {
            jsonResponse('error', 'Admin tidak dapat menghapus akunnya sendiri.', null, 403);
        }
        $stmt = $pdo->prepare('SELECT id, name, phone, role FROM users WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $target = $stmt->fetch();
        if (!$target || ($actor['role'] === 'admin' && $target['role'] === 'admin') || ($actor['role'] !== 'admin' && $target['role'] !== 'user')) {
            jsonResponse('error', 'Akun tidak ditemukan atau tidak dapat dihapus.', null, 404);
        }
        $delete = $pdo->prepare('DELETE FROM users WHERE id = :id');
        $delete->execute([':id' => $id]);
        sendWhatsApp($pdo, $target['phone'], notificationMessage('Akun telah dihapus', [
            'Halo ' . $target['name'] . '.',
            'Akun Portal ASTS Anda telah dihapus oleh admin pada ' . notificationTime() . '.',
            'Jika penghapusan ini tidak sesuai, silakan hubungi admin.',
        ], '🗑️'));
        jsonResponse('success', $id === (int) $actor['id'] ? 'Akun Anda telah dihapus.' : 'Akun telah dihapus.', []);
    }

    jsonResponse('error', 'Method HTTP tidak didukung.', null, 405);
} catch (Throwable $error) {
    error_log('Users API error: ' . $error->getMessage());
    jsonResponse('error', 'Terjadi kesalahan server.', null, 500);
}
