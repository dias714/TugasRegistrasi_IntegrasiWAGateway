<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');
require __DIR__ . '/app_common.php';
require __DIR__ . '/koneksi.php';

try {
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'GET') {
        $user = authenticatedUser($pdo);
        jsonResponse('success', 'Sesi aktif.', publicUser($user));
    }

    if ($method !== 'POST') {
        jsonResponse('error', 'Method HTTP tidak didukung.', null, 405);
    }

    $input = requestData();
    $action = (string) ($input['action'] ?? '');

    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        jsonResponse('success', 'Anda berhasil logout.');
    }

    if ($action === 'admin_phone') {
        $user = authenticatedUser($pdo);
        requireAdmin($user);
        $phone = normalizePhone((string) ($input['phone'] ?? ''));
        if (strlen($phone) < 10 || strlen($phone) > 15) {
            jsonResponse('error', 'Masukkan nomor WhatsApp admin yang valid.', null, 422);
        }
        $stmt = $pdo->prepare('UPDATE users SET phone = :phone WHERE id = :id');
        $stmt->execute([':phone' => $phone, ':id' => $user['id']]);
        $user['phone'] = $phone;
        jsonResponse('success', 'Nomor WhatsApp admin tersimpan.', publicUser($user));
    }

    if ($action === 'login') {
        $email = trim((string) ($input['email'] ?? ''));
        $password = (string) ($input['password'] ?? '');
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email ORDER BY id ASC LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
            jsonResponse('error', 'Email atau password salah, atau akun belum diaktifkan admin.', null, 401);
        }
        if (!in_array($user['role'], ['admin', 'user'], true)) {
            jsonResponse('error', 'Role akun tidak dikenali. Hubungi admin.', null, 403);
        }
        if (!(int) $user['is_active']) {
            jsonResponse('error', 'Akun Anda sedang dinonaktifkan. Hubungi admin.', null, 403);
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        $lastLogin = $pdo->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = :id');
        $lastLogin->execute([':id' => $user['id']]);
        sendWhatsApp($pdo, $user['phone'] ?? null, notificationMessage('Login berhasil', [
            'Halo ' . $user['name'] . ' 👋',
            'Anda berhasil masuk ke akun Portal ASTS pada ' . notificationTime() . '.',
            'Jika bukan Anda yang login, segera ganti password dari halaman profil dan hubungi admin.',
        ], '🔐'));
        jsonResponse('success', 'Anda berhasil login.', publicUser($user));
    }

    if ($action === 'register') {
        $required = ['name', 'nisn', 'ttl', 'gender', 'email', 'phone', 'address', 'password'];
        foreach ($required as $field) {
            if (trim((string) ($input[$field] ?? '')) === '') {
                jsonResponse('error', "Field {$field} wajib diisi.", null, 422);
            }
        }

        $name = trim((string) $input['name']);
        $nisn = trim((string) $input['nisn']);
        $gender = trim((string) $input['gender']);
        $email = trim((string) $input['email']);
        $phone = normalizePhone((string) $input['phone']);
        $password = (string) $input['password'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse('error', 'Format email tidak valid.', null, 422);
        }
        if (!preg_match('/^\d{10}$/', $nisn)) {
            jsonResponse('error', 'NISN harus terdiri dari tepat 10 angka.', null, 422);
        }
        if (!in_array($gender, ['male', 'female'], true)) {
            jsonResponse('error', 'Pilih gender yang tersedia.', null, 422);
        }
        if (strlen($password) < 8) {
            jsonResponse('error', 'Password minimal 8 karakter.', null, 422);
        }
        if (strlen($phone) < 10 || strlen($phone) > 15) {
            jsonResponse('error', 'Nomor HP harus berisi 10 sampai 15 angka.', null, 422);
        }

        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email');
        $check->execute([':email' => $email]);
        if ($check->fetch()) {
            jsonResponse('error', 'Email sudah terdaftar.', null, 409);
        }

        $stmt = $pdo->prepare(
            "INSERT INTO users (name, nisn, ttl, gender, email, phone, address, password_hash, role)
             VALUES (:name, :nisn, :ttl, :gender, :email, :phone, :address, :password_hash, 'user')"
        );
        $stmt->execute([
            ':name' => $name,
            ':nisn' => $nisn,
            ':ttl' => trim((string) $input['ttl']),
            ':gender' => $gender,
            ':email' => $email,
            ':phone' => $phone,
            ':address' => trim((string) $input['address']),
            ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ]);

        sendWhatsApp($pdo, $phone, notificationMessage('Akun berhasil dibuat', [
            'Selamat datang, ' . $name . ' 👋',
            'Email login: ' . $email,
            'Akun Anda siap digunakan. Silakan masuk menggunakan password yang Anda buat.',
            'Waktu pendaftaran: ' . notificationTime(),
            'Jangan bagikan password Anda kepada siapa pun.',
        ], '🎉'));
        notifyAdmins($pdo, notificationMessage('Pendaftar baru', [
            'Nama: ' . $name,
            'Email: ' . $email,
            'Nomor WhatsApp: ' . $phone,
            'Waktu: ' . notificationTime(),
            'Tindak lanjut: tinjau akun melalui Dashboard Admin.',
        ], '🆕'));
        jsonResponse('success', 'Pendaftaran berhasil. Silakan login.', ['id' => (int) $pdo->lastInsertId()], 201);
    }

    jsonResponse('error', 'Aksi tidak dikenal.', null, 400);
} catch (Throwable $error) {
    error_log('Auth API error: ' . $error->getMessage());
    jsonResponse('error', 'Terjadi kesalahan server.', null, 500);
}