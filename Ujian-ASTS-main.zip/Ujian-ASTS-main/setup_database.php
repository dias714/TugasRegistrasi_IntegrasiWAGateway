<?php

declare(strict_types=1);

header('Content-Type: text/html; charset=UTF-8');

$host = '127.0.0.1';
$username = 'root';
$password = '';
$database = 'ujian_asts';

try {
    $pdo = new PDO("mysql:host={$host};charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $pdo = new PDO("mysql:host={$host};dbname={$database};charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(150) NOT NULL,
            nisn VARCHAR(30) NOT NULL,
            ttl VARCHAR(150) NOT NULL,
            gender VARCHAR(20) NOT NULL,
            email VARCHAR(150) NOT NULL,
            phone VARCHAR(30) NULL,
            address TEXT NOT NULL,
            password_hash VARCHAR(255) NULL,
            role VARCHAR(20) NOT NULL DEFAULT \'user\',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_login_at DATETIME NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1
            UNIQUE KEY uq_users_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    $apiUrl = 'https://jsonplaceholder.typicode.com/users';
    $context = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $json = file_get_contents($apiUrl, false, $context);
    $sourceMessage = 'Data berhasil disinkronkan dari JSONPlaceholder.';
    if ($json === false) {
        $jsonUsers = [
            ['id' => 1, 'name' => 'Leanne Graham', 'email' => 'Sincere@april.biz', 'address' => ['street' => 'Kulas Light', 'suite' => 'Apt. 556', 'city' => 'Gwenborough', 'zipcode' => '92998-3874']],
            ['id' => 2, 'name' => 'Ervin Howell', 'email' => 'Shanna@melissa.com', 'address' => ['street' => 'Victor Plains', 'suite' => 'Suite 879', 'city' => 'Wisokyburgh', 'zipcode' => '90566-7771']],
            ['id' => 3, 'name' => 'Clementine Bauch', 'email' => 'Nathan@yesenia.net', 'address' => ['street' => 'Douglas Extension', 'suite' => 'Suite 847', 'city' => 'McKenziehaven', 'zipcode' => '59590-4157']],
            ['id' => 4, 'name' => 'Patricia Lebsack', 'email' => 'Julianne.OConner@kory.org', 'address' => ['street' => 'Hoeger Mall', 'suite' => 'Apt. 692', 'city' => 'South Elvis', 'zipcode' => '53919-4257']],
            ['id' => 5, 'name' => 'Chelsey Dietrich', 'email' => 'Lucio_Hettinger@annie.ca', 'address' => ['street' => 'Skiles Walks', 'suite' => 'Suite 351', 'city' => 'Roscoeview', 'zipcode' => '33263-0494']],
            ['id' => 6, 'name' => 'Mrs. Dennis Schulist', 'email' => 'Karley.Dach@jasper.info', 'address' => ['street' => 'Norberto Crossing', 'suite' => 'Apt. 950', 'city' => 'South Christy', 'zipcode' => '23505-1337']],
            ['id' => 7, 'name' => 'Kurtis Weissnat', 'email' => 'Telly@elvis.io', 'address' => ['street' => 'Rex Trail', 'suite' => 'Suite 280', 'city' => 'Howemouth', 'zipcode' => '58804-1099']],
            ['id' => 8, 'name' => 'Nicholas Runolfsdottir V', 'email' => 'Sherwood@rosamond.me', 'address' => ['street' => 'Ellsworth Summit', 'suite' => 'Suite 729', 'city' => 'Aliyaview', 'zipcode' => '45169-1383']],
            ['id' => 9, 'name' => 'Glenna Reichert', 'email' => 'Kayla@jasper.info', 'address' => ['street' => 'Dayna Park', 'suite' => 'Suite 449', 'city' => 'Bartholomebury', 'zipcode' => '76495-3109']],
            ['id' => 10, 'name' => 'Clementina DuBuque', 'email' => 'Kaleigh@heathcote.net', 'address' => ['street' => 'Kattie Turnpike', 'suite' => 'Suite 198', 'city' => 'South Alfred', 'zipcode' => '06742-6417']],
        ];
        $sourceMessage = 'DNS JSONPlaceholder tidak tersedia; digunakan snapshot data JSONPlaceholder.';
    } else {
        $jsonUsers = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
    }

    if (!is_array($jsonUsers) || count($jsonUsers) < 10) {
        throw new RuntimeException('Data dari JSONPlaceholder tidak memiliki 10 user yang valid.');
    }

    $existingUsers = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($existingUsers === 0) {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            'INSERT INTO users (name, nisn, ttl, gender, email, address)
             VALUES (:name, :nisn, :ttl, :gender, :email, :address)'
        );

        foreach (array_slice($jsonUsers, 0, 10) as $user) {
            $address = $user['address']['street'] . ', ' . $user['address']['suite'] . ', ' . $user['address']['city'] . ', ' . $user['address']['zipcode'];
            $stmt->execute([
                ':name' => $user['name'],
                ':nisn' => '202600' . str_pad((string) $user['id'], 4, '0', STR_PAD_LEFT),
                ':ttl' => $user['address']['city'] . ', tanggal lahir tidak tersedia',
                ':gender' => $user['id'] % 2 === 0 ? 'female' : 'male',
                ':email' => $user['email'],
                ':address' => $address,
            ]);
        }
        $pdo->commit();
        $sourceMessage .= ' Data awal hanya dimasukkan karena tabel masih kosong.';
    } else {
        $sourceMessage = 'Data lama dipertahankan; setup tidak menimpa akun yang sudah ada.';
    }

    echo '<!doctype html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Setup Database</title><link rel="stylesheet" href="app.css"></head><body>';
    echo '<main class="setup-shell"><p class="section-kicker">Konfigurasi sistem</p><h1>Setup berhasil</h1>';
    echo '<p>Database ujian_asts dan tabel users siap digunakan.</p>';
    echo '<p>' . htmlspecialchars($sourceMessage, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<p>Jumlah data saat ini: ' . htmlspecialchars((string) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(), ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<p><a href="login.html">Buka halaman login</a></p></main></body></html>';
} catch (Throwable $error) {
    http_response_code(500);
    echo '<!doctype html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Setup Gagal</title><link rel="stylesheet" href="app.css"></head><body>';
    echo '<main class="setup-shell" data-state="error"><p class="section-kicker">Konfigurasi sistem</p><h1>Setup gagal</h1>';
    echo '<p>Terjadi kesalahan: ' . htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8') . '</p></main></body></html>';
}
