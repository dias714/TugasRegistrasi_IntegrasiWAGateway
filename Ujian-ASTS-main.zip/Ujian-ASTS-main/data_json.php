<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');

$url = 'https://jsonplaceholder.typicode.com/users';
$context = stream_context_create([
    'http' => [
        'timeout' => 15,
        'ignore_errors' => true,
        'header' => "Accept: application/json\r\n",
    ],
]);

try {
    $json = file_get_contents($url, false, $context);

    if ($json === false) {
        throw new RuntimeException('Tidak dapat mengambil data dari JSONPlaceholder.');
    }

    $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);

    if (!is_array($data)) {
        throw new RuntimeException('Format data JSON tidak valid.');
    }

    echo json_encode([
        'status' => 'success',
        'message' => 'Data JSONPlaceholder berhasil diambil.',
        'data' => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $error) {
    http_response_code(502);
    echo json_encode([
        'status' => 'error',
        'message' => $error->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
