<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/koneksi.php';

try {
    $columns = $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN);
    $migrations = [
        'phone' => 'ALTER TABLE users ADD phone VARCHAR(30) NULL AFTER email',
        'password_hash' => 'ALTER TABLE users ADD password_hash VARCHAR(255) NULL AFTER address',
        'role' => "ALTER TABLE users ADD role VARCHAR(20) NOT NULL DEFAULT 'user' AFTER password_hash",
        'created_at' => 'ALTER TABLE users ADD created_at DATETIME NULL',
        'last_login_at' => 'ALTER TABLE users ADD last_login_at DATETIME NULL',
        'is_active' => 'ALTER TABLE users ADD is_active TINYINT(1) NOT NULL DEFAULT 1',
    ];

    foreach ($migrations as $column => $sql) {
        if (!in_array($column, $columns, true)) {
            $pdo->exec($sql);
        }
    }
    $pdo->exec('ALTER TABLE users MODIFY created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP');

    $emailIndex = $pdo->query("SHOW INDEX FROM users WHERE Key_name = 'uq_users_email'")->fetch();
    if (!$emailIndex) {
        $pdo->exec('ALTER TABLE users ADD UNIQUE KEY uq_users_email (email)');
    }

    $pdo->exec("UPDATE users SET nisn = '9999999999' WHERE role = 'admin' AND nisn = 'ADMIN000001'");

    $adminCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    $initialPassword = null;
    if ($adminCount === 0) {
        $initialPassword = bin2hex(random_bytes(8));
        $stmt = $pdo->prepare(
            "INSERT INTO users (name, nisn, ttl, gender, email, phone, address, password_hash, role)
             VALUES ('Administrator', '9999999999', '-', '-', 'admin@local.test', NULL, 'Akun administrator', :password_hash, 'admin')"
        );
        $stmt->execute([':password_hash' => password_hash($initialPassword, PASSWORD_DEFAULT)]);
    }

    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html lang="id"><meta charset="UTF-8"><title>Upgrade Akun</title><body><h1>Upgrade berhasil</h1>';
    echo '<p>Kolom akun siap. Data user lama tetap dipertahankan.</p>';
    if ($initialPassword !== null) {
        echo '<p>Email admin: <strong>admin@local.test</strong></p>';
        echo '<p>Password awal: <strong>' . htmlspecialchars($initialPassword, ENT_QUOTES, 'UTF-8') . '</strong></p>';
        echo '<p>Simpan password ini sekarang; password hanya ditampilkan saat admin pertama dibuat. Segera ubah setelah login.</p>';
    } else {
        echo '<p>Akun admin sudah tersedia. Tidak ada password yang ditampilkan.</p>';
    }
    echo '</body></html>';
} catch (Throwable $error) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Upgrade gagal. Periksa database users dan konfigurasi koneksi.';
    error_log('Account migration error: ' . $error->getMessage());
}